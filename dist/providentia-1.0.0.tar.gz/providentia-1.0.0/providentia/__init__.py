#!/usr/bin/env python
"""Providentia package
"""

__version__ = "1.0.0"


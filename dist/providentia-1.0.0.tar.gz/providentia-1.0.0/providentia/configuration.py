#Providentia Configuration File 

###------------------------------------------------------------------------------------###
###IMPORT BUILT-IN MODULES
###------------------------------------------------------------------------------------###

import os
import re
import subprocess
import sys

###------------------------------------------------------------------------------------###
###SETTING SOME NECESSARY DETAILS --> DO NOT MODIFY!
###------------------------------------------------------------------------------------###

#set GHOST version data to work with
GHOST_version = '1.1'

#get machine name
try:
    machine = os.environ['BSC_MACHINE']
except:
    machine = ''

#get available N CPUs
if (machine == 'power') or (machine == 'mn4'):
    bash_command = 'squeue -h -o "%C"'
    process = subprocess.Popen(bash_command.split(), stdout=subprocess.PIPE)
    output, error = process.communicate()
    available_CPUs = int(re.findall(r'\d+', str(output))[0])
else:
    available_CPUs = int(os.cpu_count())

#set cartopy data directory (needed on CTE-POWER/MN4 as has no external internet connection)
if (machine == 'power') or (machine == 'mn4'):
    cartopy_data_dir = '/gpfs/projects/bsc32/software/rhel/7.5/ppc64le/POWER9/software/Cartopy/0.17.0-foss-2018b-Python-3.7.0/lib/python3.7/site-packages/Cartopy-0.17.0-py3.7-linux-ppc64le.egg/cartopy/data'
#on all machines except CTE-POWER/MN4, pull from internet
else:
    cartopy_data_dir = ''

###------------------------------------------------------------------------------------###
###DEFINE NUMBER OF CPUs TO UTILISE
###------------------------------------------------------------------------------------###

#Define number of CPUs to process on (leave empty to automatically utilise all available CPUs)
#NOTE: if this value is set higher than the actual number of CPUs available, then the max number of CPUs is used. 
n_CPUs = ''
if (n_CPUs == '') or (int(n_CPUs) > available_CPUs):
    n_CPUs = available_CPUs

###------------------------------------------------------------------------------------###
###DEFINE OBSERVATIONAL/EXPERIMENT ROOT DATA DIRECTORIES
###------------------------------------------------------------------------------------###

#Define observational root data directory (if undefined it is automatically taken from the BSC machine the tool is ran on)
obs_root = ''
#set observational root data directory if left undefined
if obs_root == '':
    #running on CTE-POWER/MN4?
    if (machine == 'power') or (machine == 'mn4'):
        obs_root = '/gpfs/projects/bsc32/AC_cache/obs/ghost'
    #running on workstation?
    else:
        obs_root = '/esarchive/obs/ghost'
    
#Define experiment root data directory
exp_root = ''
#set experiment root data directory if left undefined
if exp_root == '':
    #running on CTE-POWER?
    if (machine == 'power') or (machine == 'mn4'):
        exp_root = '/gpfs/projects/bsc32/AC_cache/recon/ghost_interp_new'
    #running on workstation?
    else:
        exp_root = '/esarchive/recon/ghost_interp_new'

###------------------------------------------------------------------------------------###
###DEFINE COLOURMAPS (see all options here: https://matplotlib.org/examples/color/colormaps_reference.html)
###------------------------------------------------------------------------------------###

#set the sequential colourmap (used to view absolute values)
#one of the perceptually uniform sequential colourmaps is recommended here: viridis, plasma, inferno, magma
sequential_colourmap = 'viridis'

#set the warm sequential colourmap (used to view absolute biases going from zero bias to a maximum bias)
sequential_colourmap_warm = 'Reds'

#set the diverging colourmap (used to evaluate differences)
diverging_colourmap = 'bwr'

###------------------------------------------------------------------------------------###
###DEFINE PLOT MARKER SIZES
###------------------------------------------------------------------------------------###

#define marker sizes for unselected stations on map
map_unselected_station_marker_size = 3

#define marker sizes for selected stations on map
map_selected_station_marker_size = 8

#define marker sizes on legend
legend_marker_size = 11

#define marker sizes on time series plot
time_series_marker_size = 1.1

#define marker sizes on temporally aggregated plot 
temporally_aggregated_marker_size = 3

#define marker sizes on temporally aggregated experiment bias plot 
temporally_aggregated_experiment_bias_marker_size = 3

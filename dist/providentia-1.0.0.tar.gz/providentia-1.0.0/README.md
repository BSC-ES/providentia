Providentia is a visualisation tool designed to allow on-the-fly analysis of BSC experiment output, with respect to GHOST processed observational data. 
